<?php
/**
 * Resume content for widgets
 *
 * @package Jobify
 * @since 3.2.0
 * @version 3.8.0
 */

locate_template( array( 'content-resume.php' ), true, false );
