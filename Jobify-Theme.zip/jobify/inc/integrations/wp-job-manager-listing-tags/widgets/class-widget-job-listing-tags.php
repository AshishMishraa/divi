<?php
/**
 * Job Listing: Listing Tags
 *
 * @since 3.6.0
 */
class Jobify_Widget_Listing_Tags extends Jobify_Widget_Job_Tags {}
