<?php
/**
 * Install required and recommended plugins.
 *
 * @since unknown
 */

astoundify_plugininstaller_enqueue_scripts();
?>

<div class="astoundify-setupguide-install-plugins-more">
	<div class="astoundify-setupguide-install-plugins-list">
		<?php astoundify_plugininstaller_list(); ?>
	</div>
</div>
